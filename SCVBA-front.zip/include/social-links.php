<div class="col-lg-2" data-aos="fade-right"
     data-aos-easing="linear"
     data-aos-duration="1500">
  <ul class="social-links mx-auto mx-lg-0 d-flex flex-row flex-lg-column mb-20 mb-lg-0 justify-content-center justify-content-lg-between gap-20 row-gap-20">
    <li><a href="https://www.facebook.com/thescvba/"><i class="fa-brands fa-facebook-f"></i></a></li>
    <li><a href="javascript:;"><i class="fa-brands fa-x-twitter"></i></a></li>
    <li><a href="https://www.linkedin.com/company/scvba/"><i class="fa-brands fa-linkedin-in"></i></a></li>
  </ul>
</div>