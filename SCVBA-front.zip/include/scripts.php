<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
<script src="./assets/libs/libs.js"></script>
<script src="./assets/js/main.js"></script>
</body>
</html>